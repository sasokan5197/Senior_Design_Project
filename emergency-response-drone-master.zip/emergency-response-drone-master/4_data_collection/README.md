# Data Collection Scripts

## Distance.java trial data
Trial 1: 40.52251°N, 74.4611°W to 40.52226°N, 74.46129°W = 32.104 m
Trial 2: 40.52253°N, 74.46106°W to 40.52227°N, 74.46127°W = 33.925 m
Trial 3: 40.52261°N, 74.46089°W to 40.52225°N, 74.46132°W = 54.068 m
## Distance.java Code Explanation
The program will allow for the user to calculate the distance the camera has traveled. The program works by having the user enter the initial and final positions of the camera as displayed on the interface. The user enters the positons in the form of the latitude and longitude.
